var searchData=
[
  ['what',['what',['../struct_graph_viewer_1_1_custom_exception.html#ac77a0d6a0e775e10b12929816b32f757',1,'GraphViewer::CustomException']]]
];
