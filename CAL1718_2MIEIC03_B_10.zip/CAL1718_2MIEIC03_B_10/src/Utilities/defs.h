#ifndef DEFS_H_
#define DEFS_H_

#include <float.h>
#include <limits.h>
#include <vector>
#include <cstddef>
#include <iostream>

#define UNDEFINED_VALUE 0

typedef unsigned int u_int;




#endif /* DEFS_H_ */
